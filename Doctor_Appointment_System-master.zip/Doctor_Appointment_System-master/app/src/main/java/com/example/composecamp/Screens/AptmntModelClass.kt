package com.example.composecamp.Screens

class AptmntModelClass (var aptid:String,var userId: String, val Date:String , val slot: String,val Dname:String)